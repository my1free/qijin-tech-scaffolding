package com.sankuai.qcs.archetype.client.enums;

import com.facebook.swift.codec.ThriftEnum;
import com.facebook.swift.codec.ThriftField;

@ThriftEnum
public enum ServiceTypeEnum {
    KUAI(1,""),
    TAXI(2,"");

    @ThriftField(1)
    int value;

    @ThriftField(2)
    String desc;

    ServiceTypeEnum(int value, String desc){
        this.value = value;
        this.desc = desc;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
