package com.sankuai.qcs.archetype.client;

import com.facebook.swift.service.ThriftException;
import com.facebook.swift.service.ThriftMethod;
import com.facebook.swift.service.ThriftService;
import com.sankuai.qcs.archetype.client.dto.DriverDTO;
import com.sankuai.qcs.archetype.client.exception.TDriverException;
import org.apache.thrift.TException;

@ThriftService
public interface TDriverClient {
    // 获取司机信息
    @ThriftMethod(exception = {@ThriftException(type = TDriverException.class, id = 1)})
    DriverDTO getDriverId(Long id) throws TDriverException, TException;
}
