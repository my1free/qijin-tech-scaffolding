package com.sankuai.qcs.archetype.client.exception;

import com.facebook.swift.codec.ThriftConstructor;
import com.facebook.swift.codec.ThriftField;
import com.facebook.swift.codec.ThriftStruct;
import com.meituan.service.mobile.mtthrift.annotation.AbstractThriftException;

@ThriftStruct
public class TDriverException extends AbstractThriftException {

    @ThriftField(1)
    public int code;

    @ThriftField(2)
    public String message;

    @ThriftConstructor
    public TDriverException(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }


    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "TDriverException{" +
                "code=" + code +
                ", message='" + message + '\'' +
                '}';
    }
}
