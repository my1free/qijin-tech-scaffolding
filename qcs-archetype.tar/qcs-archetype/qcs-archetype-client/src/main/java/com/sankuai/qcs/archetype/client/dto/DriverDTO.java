package com.sankuai.qcs.archetype.client.dto;

import com.facebook.swift.codec.ThriftField;
import com.facebook.swift.codec.ThriftStruct;

@ThriftStruct
public class DriverDTO {

    // 司机ID
    public Long id;

    // '美团账号
    public Long mtAccountId;

    // 司机状态 -不可用 -可用
    public Integer state;

    // 类型 -快车，-出租车
    public Integer type;

    public String name;

    public String phone;

    public String headPortraitsUrl;

    public Long companyId;

    public Integer cityId;

    public Long createTime;

    public Long updateTime;


    @ThriftField(value = 1)
    public Long getId() {
        return id;
    }

    @ThriftField
    public void setId(Long id) {
        this.id = id;
    }

    @ThriftField(value = 2)
    public Long getMtAccountId() {
        return mtAccountId;
    }

    @ThriftField
    public void setMtAccountId(Long mtAccountId) {
        this.mtAccountId = mtAccountId;
    }

    @ThriftField(value = 3)
    public Integer getState() {
        return state;
    }

    @ThriftField
    public void setState(Integer state) {
        this.state = state;
    }

    @ThriftField(value = 4)
    public Integer getType() {
        return type;
    }

    @ThriftField
    public void setType(Integer type) {
        this.type = type;
    }

    @ThriftField(value = 5)
    public String getName() {
        return name;
    }

    @ThriftField
    public void setName(String name) {
        this.name = name;
    }

    @ThriftField(value = 6)
    public String getPhone() {
        return phone;
    }

    @ThriftField
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @ThriftField(value = 7)
    public String getHeadPortraitsUrl() {
        return headPortraitsUrl;
    }

    @ThriftField
    public void setHeadPortraitsUrl(String headPortraitsUrl) {
        this.headPortraitsUrl = headPortraitsUrl;
    }

    @ThriftField(value = 8)
    public Long getCompanyId() {
        return companyId;
    }

    @ThriftField
    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    @ThriftField(value = 9)
    public Integer getCityId() {
        return cityId;
    }

    @ThriftField
    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    @ThriftField(value = 10)
    public Long getCreateTime() {
        return createTime;
    }

    @ThriftField
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    @ThriftField(value = 11)
    public Long getUpdateTime() {
        return updateTime;
    }

    @ThriftField
    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "DriverDTO{" +
                "id=" + id +
                ", mtAccountId=" + mtAccountId +
                ", state=" + state +
                ", type=" + type +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", headPortraitsUrl='" + headPortraitsUrl + '\'' +
                ", companyId=" + companyId +
                ", cityId=" + cityId +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
