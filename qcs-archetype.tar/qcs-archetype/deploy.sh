#/bin/sh
cd target/generated-sources/archetype/
mvn -U clean deploy -Dmaven.test.skip=true \
-DaltReleaseDeploymentRepository=meituan-nexus-releases::default::http://pixel.sankuai.com/repository/releases/ \
-DaltSnapshotDeploymentRepository=meituan-nexus-snapshots::default::http://pixel.sankuai.com/repository/snapshots/