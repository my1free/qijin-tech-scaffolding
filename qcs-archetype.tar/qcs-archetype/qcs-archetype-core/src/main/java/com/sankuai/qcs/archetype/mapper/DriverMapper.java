package com.sankuai.qcs.archetype.mapper;

import com.sankuai.qcs.archetype.domain.Driver;
import com.sankuai.qcs.archetype.domain.DriverExample;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.type.JdbcType;

import java.util.List;

public interface DriverMapper {
    @SelectProvider(type=DriverSqlProvider.class, method="countByExample")
    long countByExample(DriverExample example);

    @DeleteProvider(type=DriverSqlProvider.class, method="deleteByExample")
    int deleteByExample(DriverExample example);

    @Delete({
        "delete from driver",
        "where id = #{id,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long id);

    @Insert({
        "insert into driver (mt_account_id, name, ",
        "phone, head_portraits_url, ",
        "company_id, city_id, ",
        "create_time, update_time)",
        "values (#{mtAccountId,jdbcType=BIGINT}, #{name,jdbcType=VARCHAR}, ",
        "#{phone,jdbcType=VARCHAR}, #{headPortraitsUrl,jdbcType=VARCHAR}, ",
        "#{companyId,jdbcType=BIGINT}, #{cityId,jdbcType=INTEGER}, ",
        "#{createTime,jdbcType=TIMESTAMP}, #{updateTime,jdbcType=TIMESTAMP})"
    })
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="id", before=false, resultType=Long.class)
    int insert(Driver record);

    @InsertProvider(type=DriverSqlProvider.class, method="insertSelective")
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="id", before=false, resultType=Long.class)
    int insertSelective(Driver record);

    @SelectProvider(type=DriverSqlProvider.class, method="selectByExample")
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.BIGINT, id=true),
        @Result(column="mt_account_id", property="mtAccountId", jdbcType=JdbcType.BIGINT),
        @Result(column="name", property="name", jdbcType=JdbcType.VARCHAR),
        @Result(column="phone", property="phone", jdbcType=JdbcType.VARCHAR),
        @Result(column="head_portraits_url", property="headPortraitsUrl", jdbcType=JdbcType.VARCHAR),
        @Result(column="company_id", property="companyId", jdbcType=JdbcType.BIGINT),
        @Result(column="city_id", property="cityId", jdbcType=JdbcType.INTEGER),
        @Result(column="create_time", property="createTime", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="update_time", property="updateTime", jdbcType=JdbcType.TIMESTAMP)
    })
    List<Driver> selectByExample(DriverExample example);

    @Select({
        "select",
        "id, mt_account_id, name, phone, head_portraits_url, company_id, city_id, create_time, ",
        "update_time",
        "from driver",
        "where id = #{id,jdbcType=BIGINT}"
    })
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.BIGINT, id=true),
        @Result(column="mt_account_id", property="mtAccountId", jdbcType=JdbcType.BIGINT),
        @Result(column="name", property="name", jdbcType=JdbcType.VARCHAR),
        @Result(column="phone", property="phone", jdbcType=JdbcType.VARCHAR),
        @Result(column="head_portraits_url", property="headPortraitsUrl", jdbcType=JdbcType.VARCHAR),
        @Result(column="company_id", property="companyId", jdbcType=JdbcType.BIGINT),
        @Result(column="city_id", property="cityId", jdbcType=JdbcType.INTEGER),
        @Result(column="create_time", property="createTime", jdbcType=JdbcType.TIMESTAMP),
        @Result(column="update_time", property="updateTime", jdbcType=JdbcType.TIMESTAMP)
    })
    Driver selectByPrimaryKey(Long id);

    @UpdateProvider(type=DriverSqlProvider.class, method="updateByExampleSelective")
    int updateByExampleSelective(@Param("record") Driver record, @Param("example") DriverExample example);

    @UpdateProvider(type=DriverSqlProvider.class, method="updateByExample")
    int updateByExample(@Param("record") Driver record, @Param("example") DriverExample example);

    @UpdateProvider(type=DriverSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(Driver record);

    @Update({
        "update driver",
        "set mt_account_id = #{mtAccountId,jdbcType=BIGINT},",
          "name = #{name,jdbcType=VARCHAR},",
          "phone = #{phone,jdbcType=VARCHAR},",
          "head_portraits_url = #{headPortraitsUrl,jdbcType=VARCHAR},",
          "company_id = #{companyId,jdbcType=BIGINT},",
          "city_id = #{cityId,jdbcType=INTEGER},",
          "create_time = #{createTime,jdbcType=TIMESTAMP},",
          "update_time = #{updateTime,jdbcType=TIMESTAMP}",
        "where id = #{id,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(Driver record);
}