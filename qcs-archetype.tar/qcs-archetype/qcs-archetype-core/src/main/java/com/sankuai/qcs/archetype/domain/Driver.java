package com.sankuai.qcs.archetype.domain;

import java.util.Date;

public class Driver {
    private Long id;

    private Long mtAccountId;

    private String name;

    private String phone;

    private String headPortraitsUrl;

    private Long companyId;

    private Integer cityId;

    private Date createTime;

    private Date updateTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMtAccountId() {
        return mtAccountId;
    }

    public void setMtAccountId(Long mtAccountId) {
        this.mtAccountId = mtAccountId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getHeadPortraitsUrl() {
        return headPortraitsUrl;
    }

    public void setHeadPortraitsUrl(String headPortraitsUrl) {
        this.headPortraitsUrl = headPortraitsUrl == null ? null : headPortraitsUrl.trim();
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", mtAccountId=").append(mtAccountId);
        sb.append(", name=").append(name);
        sb.append(", phone=").append(phone);
        sb.append(", headPortraitsUrl=").append(headPortraitsUrl);
        sb.append(", companyId=").append(companyId);
        sb.append(", cityId=").append(cityId);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append("]");
        return sb.toString();
    }
}