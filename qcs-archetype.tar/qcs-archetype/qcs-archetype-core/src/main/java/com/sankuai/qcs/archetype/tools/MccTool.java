package com.sankuai.qcs.archetype.tools;

import com.sankuai.meituan.config.MtConfigClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

/**
 * Mcc 初始化及监听变更
 * 提供 Mcc 数据读工具 : MccTool.get("key")
 */
@Configuration
@Slf4j
public class MccTool {

    @Value("${app.name}")
    private String appName;

    private static MtConfigClient mtConfigClient;

    @Bean(initMethod = "init", destroyMethod = "close")
    public MtConfigClient mtConfigClient() {
        MtConfigClient client = new MtConfigClient();
        client.setModel("v2");
        client.setId("MccConfiguration");
        client.setAppkey(appName);
        client.setScanBasePackage("com.sankuai.qcs");
        return client;
    }

    @PostConstruct
    public void init() {
        mtConfigClient = mtConfigClient();
    }

    public static String get(String key) {
        return mtConfigClient.getValue(key);
    }

    public static String getString(String key) {
        try {
            return get(key);
        } catch (Exception e) {
            log.error("get string from mcc error ! e = {}", e.getMessage(), e);
            return null;
        }
    }

    public static boolean getBoolean(String key) {
        try {
            String value = get(key);
            return value != null && Boolean.parseBoolean(value);
        } catch (Exception e) {
            log.error("get boolean from mcc error ! e = {}", e.getMessage(), e);
            return false;
        }
    }

    public static Integer getInt(String key) {
        try {
            String value = get(key);
            return value == null ? null : Integer.parseInt(value);
        } catch (Exception e) {
            log.error("get int from mcc error ! e = {}", e.getMessage(), e);
            return null;
        }
    }

    public static Long getLong(String key) {
        try {
            String value = get(key);
            return value == null ? null : Long.parseLong(value);
        } catch (Exception e) {
            log.error("get long from mcc error ! e = {}", e.getMessage(), e);
            return null;
        }
    }

    public static String getString(String key, String defaultValue) {
        String value = getString(key);
        return value == null ? defaultValue : value;
    }

    public static Integer getInt(String key, Integer defaultValue) {
        Integer value = getInt(key);
        return value == null ? defaultValue : value;
    }

    public static Long getLong(String key, Long defaultValue) {
        Long value = getLong(key);
        return value == null ? defaultValue : value;
    }
}
