package com.sankuai.qcs.archetype.threadlocal;

import com.dianping.cat.message.Transaction;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class ThreadCache {
    private static final ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal();
    private static final String OPERATOR = "operator";
    private static final String OPERATE_TIME = "operateTime";
    private static final String CAT_TRANSACTION = "catTransaction";

    public static void init() {
        threadLocal.set(new HashMap<>());
    }

    private static Map<String, Object> get() {
        if(threadLocal.get() == null){
            init();
        }
        return threadLocal.get();
    }

    public static Integer getOperateTime() {
        Integer operateTime = (Integer) get().get(OPERATE_TIME);
        if (operateTime == null) {
            return (int) Instant.now().getEpochSecond();
        }
        return operateTime;
    }

    public static void setOperateTime(Integer operateTime) {
        get().put(OPERATE_TIME,operateTime);
    }

    public static String getOperator() {
        String operator = (String) get().get(OPERATOR);
        if (operator == null) {
            return "";
        }
        return operator;
    }

    public static void setOperator(String operator) {
        get().put(OPERATOR,operator);
    }

    public static void setCatTransaction(Transaction transaction){
        get().put(CAT_TRANSACTION, transaction);
    }

    public static Transaction getCatTransaction(){
        return (Transaction) get().get(CAT_TRANSACTION);
    }

}
