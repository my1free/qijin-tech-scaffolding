package com.sankuai.qcs.archetype.service;

import com.sankuai.qcs.archetype.domain.Driver;
import com.sankuai.qcs.archetype.mapper.DriverMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class DriverService {
    @Resource
    private DriverMapper driverMapper;

    public Driver getById(Long id){
        return driverMapper.selectByPrimaryKey(id);
    }


}
