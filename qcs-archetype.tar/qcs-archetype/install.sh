#/bin/sh
cd target/generated-sources/archetype/
mvn -U clean install
