package com.sankuai.qcs.archetype.test;

import com.meituan.service.inf.kms.client.KmsAuthDataSource;
import com.meituan.service.mobile.mtthrift.auth.DefaultAuthHandler;
import com.meituan.service.mobile.mtthrift.auth.DefaultSignHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KmsAuthConfig {

    @Value("${app.name}")
    private String appName;

    @Bean(name = "defaultSignHandler")
    public DefaultSignHandler defaultSignHandler() throws Exception {
        //统一鉴权 服务消费者用
        KmsAuthDataSource kmsAuthDataSource = new KmsAuthDataSource();
        kmsAuthDataSource.setAppkey(appName);
        DefaultSignHandler defaultSignHandler = new DefaultSignHandler();
        defaultSignHandler.setAuthDataSource(kmsAuthDataSource);
        defaultSignHandler.afterPropertiesSet();  //API方式必须增加afterPropertiesSet
        return defaultSignHandler;
    }
}
