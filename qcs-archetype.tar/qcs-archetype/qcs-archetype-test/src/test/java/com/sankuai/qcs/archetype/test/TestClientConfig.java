package com.sankuai.qcs.archetype.test;

import com.meituan.service.mobile.mtthrift.auth.DefaultSignHandler;
import com.meituan.service.mobile.mtthrift.proxy.ThriftClientProxy;
import com.sankuai.qcs.archetype.client.TDriverClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;

@Configuration
public class TestClientConfig {

    @Value("${app.name}")
    private String appkey;
    @Resource
    private DefaultSignHandler defaultSignHandler;

//    注入一个想要测试的thrift服务的客户端，如果是直连，必须设置参数remoteUniProto为true
    @Bean(value = "testDriverClient", destroyMethod = "destroy")
    public ThriftClientProxy testDriverClient() throws Exception {
        ThriftClientProxy thriftClientProxy = new ThriftClientProxy();
        thriftClientProxy.setAppKey(appkey);
        thriftClientProxy.setServiceInterface(TDriverClient.class);
        thriftClientProxy.setRemoteAppkey(appkey); //自己调用自己
        thriftClientProxy.setServerIpPorts("127.0.0.1:9001");
        thriftClientProxy.setRemoteUniProto(true);
        thriftClientProxy.setTimeout(1000);
        thriftClientProxy.setSignHandler(defaultSignHandler); //统一鉴权配置
        thriftClientProxy.afterPropertiesSet();
        return thriftClientProxy;
    }
}
