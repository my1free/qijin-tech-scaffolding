package com.sankuai.qcs.archetype.test;

import com.sankuai.qcs.archetype.client.TDriverClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestAppStarter.class)
public class ThriftServiceTest {

    @Resource
    private TDriverClient testDriverClient;


    //运行该方法即可进行单测
    @Test
    public void test() throws Exception {
        System.out.println(testDriverClient.getDriverId(117L));
    }
}
