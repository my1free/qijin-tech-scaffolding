#!/usr/bin/env bash
# ------------------------------------
# 编译打包项目
# -----------------------------------

set -e

echo "compile start...."

mvn clean -U package -pl $PACKAGE_PATH -am -P $PROFILE  -Dmaven.test.skip=$SKIP_TEST

cd $(dirname $0)/..

mkdir target/dist

cp -r deploy target/dist/

cp target/*.jar target/dist/

echo "compile end...."