#!/bin/sh

# ------------------------------------
# https://wiki.sankuai.com/pages/viewpage.action?pageId=810461798
# -----------------------------------

echo "check http service!"

http_code=`curl -o /dev/null -s -w %{http_code} http://localhost:8080/api/monitor/alive`

echo "http_code: $http_code"

if [ $http_code == 200 ]
then
    echo "check http succeeded!"
    exit 0
elif [ $http_code == 302 ]
then
    echo "check http failed!, cause: maybe use SSO for check url!"
    exit 1
else
    echo "check http failed!"
    exit 2
fi