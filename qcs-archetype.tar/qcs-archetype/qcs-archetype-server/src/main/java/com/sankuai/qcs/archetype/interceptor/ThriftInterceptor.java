package com.sankuai.qcs.archetype.interceptor;

import com.alibaba.fastjson.JSON;
import com.meituan.mtrace.Tracer;
import com.sankuai.qcs.archetype.client.exception.TDriverException;
import com.sankuai.qcs.archetype.threadlocal.ThreadCache;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.time.Instant;

@Component
@Aspect
@Slf4j
public class ThriftInterceptor {

    @Pointcut("execution(public * com.sankuai.qcs.archetype.thrift.*.*(..))")
    public void cutMethod() {
    }

    @Before("cutMethod()")
    public void before(JoinPoint jp){
        //打点 & log
        Signature signature = jp.getSignature();
        log.info("[Thrift request] {}.{}.traceId_{}.params:{}", signature.getDeclaringTypeName(),signature.getName(),Tracer.getServerTracer().getTraceId(),JSON.toJSONString(jp.getArgs()));
        //init threadCache
        ThreadCache.init();
        ThreadCache.setOperateTime((int) Instant.now().getEpochSecond());
    }

    @AfterReturning(returning = "result",pointcut = "cutMethod()")
    public void afterReturning(JoinPoint jp, Object result) {
        Signature signature = jp.getSignature();
        log.info("[Thrift response] {}.{}.traceId_{}.result:{}", signature.getDeclaringTypeName(),signature.getName(),Tracer.getServerTracer().getTraceId(),JSON.toJSONString(result));
    }

    @AfterThrowing(pointcut = "cutMethod()",throwing="ex")
    public Object afterThrowing(JoinPoint jp, Throwable ex) throws TDriverException{
        Signature signature = jp.getSignature();
        if (ex instanceof TDriverException) {
            throw (TDriverException) ex;
        } else {
            // 打印exception
            log.error("[Thrift exception] {}.{}.traceId_{}.e:{}",signature.getDeclaringTypeName(),signature.getName(),Tracer.getServerTracer().getTraceId(),ex.getMessage(),ex);
            // 包装ex
            throw new TDriverException(500,"抱歉，服务器开了个小差！请稍后再试！");
        }
    }

}
