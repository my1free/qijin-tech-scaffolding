package com.sankuai.qcs.archetype.app;

import com.meituan.service.mobile.mtthrift.auth.DefaultSignHandler;
import com.meituan.service.mobile.mtthrift.proxy.ThriftClientProxy;
import com.sankuai.qcs.archetype.client.TDriverClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;

@Configuration
public class ClientConfig {

    @Value("${app.name}")
    private String appName;
    //统一鉴权
    @Resource
    private DefaultSignHandler defaultSignHandler;

    //一个Client配置示例
    @Bean(value = "testDriverClient", destroyMethod = "destroy")
    public ThriftClientProxy testDriverClient() throws Exception {
        ThriftClientProxy thriftClientProxy = new ThriftClientProxy();
        thriftClientProxy.setAppKey(appName);
        thriftClientProxy.setServiceInterface(TDriverClient.class);
        thriftClientProxy.setRemoteAppkey("com.sankuai.resv.c.crane");  //server端的appkey
        thriftClientProxy.setRemoteServerPort(9001);
        thriftClientProxy.setRemoteUniProto(true);
        thriftClientProxy.setTimeout(1000);
        thriftClientProxy.setSignHandler(defaultSignHandler); //统一鉴权配置
        thriftClientProxy.afterPropertiesSet();
        return thriftClientProxy;
    }


}
