package com.sankuai.qcs.archetype.listener;

import com.meituan.mafka.client.consumer.ConsumeStatus;
import com.meituan.mafka.client.consumer.IMessageListener;
import com.meituan.mafka.client.message.MafkaMessage;
import com.meituan.mafka.client.message.MessagetContext;
import com.sankuai.qcs.archetype.threadlocal.ThreadCache;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by vermouth on 12/7/16.
 */
@Slf4j
public abstract class BaseMQListener implements IMessageListener {

    @Override
    public ConsumeStatus recvMessage(MafkaMessage message, MessagetContext context) {
        String messageBody = (String) message.getBody();
        log.info("message received. topic:{}; content: {}", message.getTopic(), messageBody);
        ThreadCache.init();
        process(messageBody);
        return ConsumeStatus.CONSUME_SUCCESS;
    }

    protected abstract void process(String messageBody);
}
