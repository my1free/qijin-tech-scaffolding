package com.sankuai.qcs.archetype.app;

import com.meituan.mtrace.http.TraceHandlerInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class InterceptorConfig {

    @Value("${app.name}")
    private String appName;

    @Value("${server.port}")
    private Integer serverPort;

    @Bean
    public TraceHandlerInterceptor traceHandlerInterceptor(){
        TraceHandlerInterceptor traceHandlerInterceptor = new TraceHandlerInterceptor();
        traceHandlerInterceptor.setAppkey(appName);
        traceHandlerInterceptor.setPort(serverPort);
        return traceHandlerInterceptor;
    }
}
