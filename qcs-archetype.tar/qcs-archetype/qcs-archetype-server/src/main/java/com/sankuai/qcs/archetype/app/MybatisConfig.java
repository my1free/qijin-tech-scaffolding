package com.sankuai.qcs.archetype.app;

import com.dianping.zebra.dao.mybatis.ZebraMapperScannerConfigurer;
import com.dianping.zebra.group.jdbc.GroupDataSource;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.io.IOException;

/**
 * 数据源 & 事务管理器配置
 */
@Configuration
@EnableTransactionManagement  //开启事务管理
public class MybatisConfig {

    @Configuration
    class DataSourceConfig{

        @Value("${zebra.jdbcRef}")
        private String jdbcRef;

        @Bean
        public DataSource zebraDataSource() {
            GroupDataSource dataSource = new GroupDataSource(jdbcRef);
            dataSource.setPoolType("tomcat-jdbc");
            dataSource.setRouterType("master-only");
            dataSource.setMinPoolSize(10);
            dataSource.setMaxPoolSize(60);
            dataSource.setInitialPoolSize(10);
            dataSource.setConnectionInitSql("set names utf8mb4");
            dataSource.setForceWriteOnLogin(false);
            dataSource.setPreferredTestQuery("SELECT 1");
            dataSource.setExtraJdbcUrlParams("zeroDateTimeBehavior=convertToNull");
            dataSource.init();
            return dataSource;
        }

        @Bean(name="sqlSessionFactory")
        public SqlSessionFactoryBean sqlSessionFactory(DataSource zebraDataSource) throws IOException {
            SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
            sqlSessionFactoryBean.setDataSource(zebraDataSource);
            //如果你是将sql写在映射xml文件中，那么需要通过以下方式指定xml文件路径；本案例是直接通过注解来编写sql，因此不需要使用以下配置。
            //PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
            //sqlSessionFactoryBean.setMapperLocations(resolver.getResources("classpath*:config/sqlmap/**/*.xml"));
            return sqlSessionFactoryBean;
        }
    }


    @Bean
    public static ZebraMapperScannerConfigurer mapperScannerConfigurer() throws IOException {
        ZebraMapperScannerConfigurer configurer = new ZebraMapperScannerConfigurer();
        configurer.setSqlSessionFactoryBeanName("sqlSessionFactory");
        configurer.setBasePackage("com.sankuai.qcs.archetype.mapper");
        return configurer;
    }

    @Bean(name = "transactionManager")
    public DataSourceTransactionManager transactionManager(DataSource zebraDataSource) {
        DataSourceTransactionManager dataSourceTransactionManager = new DataSourceTransactionManager(zebraDataSource);
        dataSourceTransactionManager.setDefaultTimeout(10);
        return dataSourceTransactionManager;
    }

}
