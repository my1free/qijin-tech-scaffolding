package com.sankuai.qcs.archetype.app;


import org.springframework.context.annotation.Configuration;

/**
 * squirrel client 配置
 */
@Configuration
public class SquirrelConfig {

    //配置在 yml 文件中的属性
//    @Value("${squirrel.clusterName}")
//    private String clusterName;
//
//    @Value("${squirrel.routerType}")
//    private String routerType;
//
//    @Value("${squirrel.readTimeout}")
//    private Integer readTimeout;

//    @Bean(name = "redisClient")
//    public RedisClientBeanFactory redisClient(){
//        RedisClientBeanFactory redisClientBeanFactory = new RedisClientBeanFactory();
//        redisClientBeanFactory.setClusterName(clusterName);
//        redisClientBeanFactory.setRouterType(routerType);
//        redisClientBeanFactory.setReadTimeout(readTimeout);
//        redisClientBeanFactory.setPoolMaxIdle(16);
//        redisClientBeanFactory.setPoolMaxTotal(32);
//        redisClientBeanFactory.setPoolWaitMillis(500);
//        redisClientBeanFactory.setPoolMinIdle(3);
//        redisClientBeanFactory.setAsyncCoreSize(16);
//        redisClientBeanFactory.setAsyncMaxSize(64);
//        redisClientBeanFactory.setAsyncQueueSize(1000);
//        redisClientBeanFactory.setMultiCoreSize(16);
//        redisClientBeanFactory.setMultiMaxSize(64);
//        redisClientBeanFactory.setMultiQueueSize(1000);
//        return redisClientBeanFactory;
//    }

}
