package com.sankuai.qcs.archetype.controller;

import com.google.common.collect.ImmutableMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/monitor")
public class MonitorApiController {
    @RequestMapping("/alive")
    public Map<String, String> alive() {
        return ImmutableMap.<String, String>builder().put("status", "ok").build();
    }
}
