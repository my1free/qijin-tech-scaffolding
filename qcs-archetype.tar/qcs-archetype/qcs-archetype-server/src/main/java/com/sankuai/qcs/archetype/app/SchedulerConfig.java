package com.sankuai.qcs.archetype.app;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SchedulerConfig {

    @Value("${app.name}")
    private String appName;

    //这是一个示例
//    @Bean(name = "scheduleManager", initMethod = "init", destroyMethod = "destroy")
//    public ScheduleManager scheduleManager() throws Exception {
//        ScheduleManager scheduleManager = new ScheduleManager();
//        scheduleManager.setTaskAcceptorPort(8410);
//        scheduleManager.setTaskCallBackPort(8383);
//        Map<String, ITaskHandler> initedJobs = new HashMap<>();
////      示例：initedJobs.put("xxxx",注入的scheduler);
//        scheduleManager.setInitedJobs(initedJobs);
//        return scheduleManager;
//    }

}
