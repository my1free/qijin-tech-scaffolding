package com.sankuai.qcs.archetype.scheduler;

import com.cip.crane.client.ITaskHandler;
import com.cip.crane.netty.protocol.ScheduleTask;
import com.sankuai.qcs.archetype.threadlocal.ThreadCache;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by vermouth on 16/12/13.
 * crane的基类
 * 处理：
 * 1、日志打印
 * 2、初始化threadCache，放入operator
 */
@Slf4j
public abstract class BaseScheduler implements ITaskHandler {

    @Override
    public void handleTask(ScheduleTask scheduleTask) throws Exception {
        log.info("[scheduler] start scheduler! task name = {} , job unique code = {}", scheduleTask.getTaskName(),scheduleTask.getJobUniqueCode());
        ThreadCache.init();
        ThreadCache.setOperator(scheduleTask.getTaskName());
        doHandle(scheduleTask);
    }

    public abstract void doHandle(ScheduleTask scheduleTask);
}
