package com.sankuai.qcs.archetype.app;

import com.meituan.mtrace.http.TraceHandlerInterceptor;
import com.sankuai.qcs.archetype.interceptor.HttpInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer{

    @Resource
    private HttpInterceptor httpInterceptor;
    @Resource
    private TraceHandlerInterceptor traceHandlerInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(httpInterceptor).excludePathPatterns("/favicon.ico").addPathPatterns("/**"); //init thread local
        registry.addInterceptor(traceHandlerInterceptor).excludePathPatterns("/favicon.ico").addPathPatterns("/**");   //octo 上报
    }
}
