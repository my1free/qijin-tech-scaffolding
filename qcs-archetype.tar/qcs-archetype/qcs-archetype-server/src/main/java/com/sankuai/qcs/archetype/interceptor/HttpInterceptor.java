package com.sankuai.qcs.archetype.interceptor;

import com.alibaba.fastjson.JSONObject;
import com.dianping.cat.Cat;
import com.dianping.cat.CatConstants;
import com.dianping.cat.message.Transaction;
import com.sankuai.qcs.archetype.exception.BusinessException;
import com.sankuai.qcs.archetype.threadlocal.ThreadCache;
import com.sankuai.qcs.archetype.tools.ResponseTool;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.Map;

/**
 * Created by vermouth on 17/3/1.
 */
@Component
@Slf4j
public class HttpInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        log.info("http request : request = {} , args = {}" ,request.getRequestURI(),request.getParameterMap());
        try {
            ThreadCache.init();
            Transaction transaction = Cat.newTransaction(CatConstants.TYPE_URL, request.getRequestURI());
            transaction.setStatus(Transaction.SUCCESS);
            ThreadCache.setCatTransaction(transaction);
        }catch (Exception e){
            log.error("get cat transaction error!");
        }
        return true;
    }


    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        try{
            Transaction transaction = ThreadCache.getCatTransaction();
            if(transaction != null){
                if(ex!=null){
                    transaction.setStatus(ex);
                }
                transaction.complete();
            }
        } catch (Exception e){
            log.error("complete cat transaction error!");
        }
        if(ex!=null){
            log.error("http error : request = {} , args = {}" ,request.getRequestURI(), request.getParameterMap(), ex);
            writeException2Response(response,ex);
        }
    }

    private void writeException2Response(HttpServletResponse response, Exception ex) {
        response.setStatus(HttpServletResponse.SC_OK);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/plain; charset=UTF-8");

        Map<String, Object> exceptionResponse = null;
        if (ex instanceof BusinessException) {
            BusinessException bizEx = (BusinessException) ex;
            exceptionResponse = ResponseTool.fail(bizEx.getCode(), bizEx.getMessage());
        } else {
            exceptionResponse = ResponseTool.fail("服务器开了个小差,请稍后再试!");
        }
        PrintWriter pw = null;
        try {
            String json = JSONObject.toJSONString(exceptionResponse);
            pw = response.getWriter();
            pw.println(json);
            pw.flush();
        } catch (Exception e) {
            log.warn("Resolver error", e);
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }
}
