package com.sankuai.qcs.archetype.app;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * 消息配置
 */
@Configuration
public class MQConfig {

    @Value("${app.name}")
    private String appName;

    //    这是一个生产者示例
//    @Bean(name = "orderStatusChangedProducer",initMethod = "start",destroyMethod = "close")
//    public MafkaProducer orderStatusChangedProducer(){
//        MafkaProducer mafkaProducer = new MafkaProducer();
//        mafkaProducer.setNamespace("xxx");
//        mafkaProducer.setAppkey(appName);
//        mafkaProducer.setTopic("xxx");
//        return mafkaProducer;
//    }


    //    这是一个消费者示例
//    @Bean(name = "orderEvaluatedConsumer",initMethod = "start",destroyMethod = "close")
//    public MafkaConsumer orderEvaluatedConsumer(){
//        MafkaConsumer mafkaConsumer = new MafkaConsumer();
//        mafkaConsumer.setNamespace("xxx");
//        mafkaConsumer.setAppkey(appName);
//        mafkaConsumer.setTopic("xxx");
//        mafkaConsumer.setGroup("xxxx");
//        mafkaConsumer.setListener(注入 listener);
//        mafkaConsumer.setClassName(String.class.getName());
//        return mafkaConsumer;
//    }
}
