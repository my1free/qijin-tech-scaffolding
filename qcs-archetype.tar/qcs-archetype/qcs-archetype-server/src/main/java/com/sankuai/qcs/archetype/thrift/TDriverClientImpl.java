package com.sankuai.qcs.archetype.thrift;

import com.sankuai.qcs.archetype.client.TDriverClient;
import com.sankuai.qcs.archetype.client.dto.DriverDTO;
import com.sankuai.qcs.archetype.client.exception.TDriverException;
import com.sankuai.qcs.archetype.domain.Driver;
import com.sankuai.qcs.archetype.factory.DriverDTOFactory;
import com.sankuai.qcs.archetype.service.DriverService;
import lombok.extern.slf4j.Slf4j;
import org.apache.thrift.TException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
@Slf4j
public class TDriverClientImpl implements TDriverClient {
    @Resource
    private DriverService driverService;
    @Resource
    private DriverDTOFactory driverDTOFactory;

    @Override
    public DriverDTO getDriverId(Long id) throws TDriverException, TException {
        Driver driver = driverService.getById(id);
        return driverDTOFactory.create(driver);
    }
}
