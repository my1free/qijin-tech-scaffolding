package com.sankuai.qcs.archetype.factory;

import com.sankuai.qcs.archetype.client.dto.DriverDTO;
import com.sankuai.qcs.archetype.domain.Driver;
import org.springframework.stereotype.Service;

@Service
public class DriverDTOFactory {

    public DriverDTO create(Driver driver){
        if(driver == null){
            return null;
        }
        DriverDTO driverDTO = new DriverDTO();
        driverDTO.setId(driver.getId());
        driverDTO.setMtAccountId(driver.getMtAccountId());
        driverDTO.setCityId(driver.getCityId());
        driverDTO.setName(driver.getName());
        //其他省略
        return driverDTO;
    }
}
