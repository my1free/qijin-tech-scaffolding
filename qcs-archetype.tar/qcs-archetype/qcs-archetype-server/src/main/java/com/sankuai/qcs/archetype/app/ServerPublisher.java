package com.sankuai.qcs.archetype.app;

import com.meituan.service.mobile.mtthrift.auth.DefaultAuthHandler;
import com.meituan.service.mobile.mtthrift.proxy.ThriftServerPublisher;
import com.meituan.service.mobile.mtthrift.proxy.ThriftServiceBean;
import com.sankuai.qcs.archetype.client.TDriverClient;
import com.sankuai.qcs.archetype.thrift.TDriverClientImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class ServerPublisher {

    @Value("${app.name}")
    private String appName;
    //鉴权handler
    @Resource
    private DefaultAuthHandler defaultAuthHandler;

    //示例：接口实现类
    @Resource
    private TDriverClientImpl tDriverClientImpl;


    @Bean(name = "tDriverClient",initMethod = "publish",destroyMethod = "destroy")
    public ThriftServerPublisher thriftServerPublisher(){
        ThriftServerPublisher thriftServerPublisher = new ThriftServerPublisher();
        thriftServerPublisher.setAppKey(appName);
        thriftServerPublisher.setPort(9001);
        thriftServerPublisher.setAuthHandler(defaultAuthHandler); //统一鉴权
        //示例：单端口多服务
        Map<Class<?>, ThriftServiceBean> serviceProcessorMap = new HashMap<>();
        serviceProcessorMap.put(TDriverClient.class,tDriverClientBean());
        thriftServerPublisher.setServiceProcessorMap(serviceProcessorMap);
        //示例：单端口单服务
//        thriftServerPublisher.setServiceInterface(TDriverClient.class);
//        thriftServerPublisher.setServiceImpl(tDriverClientImpl);
        return thriftServerPublisher;
    }

    @Bean(name = "tDriverClientBean")
    public ThriftServiceBean tDriverClientBean(){
        ThriftServiceBean thriftServiceBean = new ThriftServiceBean();
        thriftServiceBean.setServiceImpl(tDriverClientImpl);
        return thriftServiceBean;
    }

}
