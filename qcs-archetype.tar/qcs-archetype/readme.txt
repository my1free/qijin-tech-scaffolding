
=============== 脚手架生成说明 =================
||             认真做好每个优化                ||
||             提高整个团队效率                ||
==============================================

首先，在当前服务的基础上做必要性开发，务必测试通过后按下述步骤生成archetype

step 1  在服务根目录下根据骨架生成 archetype (generate.sh)
        mvn archetype:create-from-project -Darchetype.properties=archetype.properties  生成 target 目录

step 2 ： 进入 target 目录调整一些配置  ------ 如果你使用的是 generate.sh ，则不需要step2
        2.1  将 gitignore 命名变更为 .gitignore （createFromProject 时的 bug，需手动加点）
        2.2  archetype-metadata.xml 配置(target/generated-sources/archetype/src/main/resources/META-INF/maven/archetype-metadata.xml)
               用如下内容覆盖整个requiredProperties标签：
                  <requiredProperties>
                    <requiredProperty key="groupId">
                      <defaultValue>com.sankuai.qcs</defaultValue>
                    </requiredProperty>
                    <requiredProperty key="version">
                      <defaultValue>1.0-SNAPSHOT</defaultValue>
                    </requiredProperty>
                    <requiredProperty key="package"/>
                    <requiredProperty key="packageName">
                      <defaultValue>${package}</defaultValue>
                    </requiredProperty>
                    <requiredProperty key="appkey">
                      <defaultValue>com.sankuai.resv.c.crane</defaultValue>
                    </requiredProperty>
                  </requiredProperties>
                特殊说明：packageName 和 package 值相同。但由于项目中的占位符为${packageName}，所以通过这种方式为 packageName 赋值。
                这个修改方式考虑之后改成自动的，用 python 操作 dom 树实现。目前还是手动来改吧。

step3 :  把脚手架 install 到本地 (install.sh)
       cd target/generated-sources/archetype
       mvn clean install

step4 :  尝试从本地 archetype 生成新服务
        mvn archetype:generate -DarchetypeCatalog=local -DartifactId=qcs-demo -Dpackage=com.sankuai.qcs.demo -Dappkey=com.sankuai.qcs.demo
        参数说明：
           artifactId：必须指定。一般格式为 qcs-xxx
           package：必须指定。根目录包——starter 所在的包,一般格式为 com.sankuai.qcs.xxx
           appkey：可选。如果暂时未在octo注册，则可以不填写，会使用默认值。但注意，不可长期使用！！

step 5 ：经过验证及调试，确定可以发布新版脚手架，则 deploy 到远程 (deploy.sh)  ！！！注意这一步之前一定要共同 review 代码！！！
        mvn -U clean deploy \
        -DaltReleaseDeploymentRepository=meituan-nexus-releases::default::http://pixel.sankuai.com/repository/releases/ \
        -DaltSnapshotDeploymentRepository=meituan-n exus-snapshots::default::http://pixel.sankuai.com/repository/snapshots/
        这里特别想提醒一下，SNAPSHOT版本记得改版本号，release版本慎重发行，一定要经过验证后再deploy上去防止误用

step 6 ：授人以鱼
        告诉小伙伴，这样就能使用最新的脚手架了
        mvn archetype:generate -Dfilter=com.sankuai.qcs:qcs-archetype \
        -DartifactId=qcs-demo -Dpackage=com.sankuai.qcs.demo -Dappkey=com.sankuai.resv.c.crane

        参数说明：
          artifactId：必须指定。一般格式为 qcs-xxx
          package：必须指定。根目录包——starter 所在的包,一般格式为 com.sankuai.qcs.xxx
          appkey：可选。如果暂时未在octo注册，则可以不填写，会使用默认值。但注意，不可长期使用！！

