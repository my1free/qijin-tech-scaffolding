#/bin/sh
mvn -U clean archetype:create-from-project -Darchetype.properties=archetype.properties

#重命名 gitignore 文件
cd target/generated-sources/archetype/src/main/resources/archetype-resources/
mv gitignore .gitignore

cd -
python ./reload_required_properties.py