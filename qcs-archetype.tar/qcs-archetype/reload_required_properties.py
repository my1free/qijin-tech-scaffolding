# coding=utf-8
# encoding = utf-8
# ###################################################### #
#            修改archetype-metadata默认变量                #
# ###################################################### #

__author__ = 'vermouth'

import codecs
from xml.dom import minidom

archetype_xml_path = 'target/generated-sources/archetype/src/main/resources/META-INF/maven/archetype-metadata.xml'
clear_default_params = 'packageName'
add_required_params = ['groupId:com.sankuai.qcs','version:1.0-SNAPSHOT','packageName:${package}']

tree = minidom.parse(archetype_xml_path)
project = tree.documentElement
requiredProperties = project.getElementsByTagName("requiredProperties")[0].childNodes

# 去掉参数默认值
for requiredProperty in requiredProperties:
    if(isinstance(requiredProperty, minidom.Element)) :
        if (requiredProperty.getAttribute("key") in clear_default_params) :
            requiredProperties.remove(requiredProperty)

# 添加必要的参数
for required_param in add_required_params:
    requiredProperty = tree.createElement("requiredProperty")
    requiredProperty.setAttribute("key", required_param.split(":")[0])
    defaultValue = tree.createElement("defaultValue")
    defaultValue.appendChild(tree.createTextNode(required_param.split(":")[1]))
    requiredProperty.appendChild(defaultValue)
    project.getElementsByTagName("requiredProperties")[0].appendChild(tree.createTextNode("\t"))
    project.getElementsByTagName("requiredProperties")[0].appendChild(requiredProperty)
    project.getElementsByTagName("requiredProperties")[0].appendChild(tree.createTextNode("\n"))

file = codecs.open(archetype_xml_path, "w", "utf-8")
tree.writexml(file,encoding="utf-8")
file.close()